module.exports = {
    multipleStatements: true,
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'pemweb_sipinjam'
};